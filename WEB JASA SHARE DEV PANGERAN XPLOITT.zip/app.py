
from flask import Flask, render_template, request, redirect, url_for
import os
import telebot

app = Flask(__name__)

BOT_TOKEN = os.getenv("7722354494:AAECyvHnvJ6jd1uK58ApyC7sKbzwPrfmijo")
DEVELOPER_CHAT_ID = os.getenv("@kebutuhanandayes")
DEV_KEY = os.getenv("pangeran_super_secret")

bot = telebot.TeleBot(7722354494:AAECyvHnvJ6jd1uK58ApyC7sKbzwPrfmijo)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        text = request.form.get("message")
        target = request.form.get("target")
        if text and target:
            try:
                bot.send_message(target, text)
                return render_template("index.html", success=True)
            except Exception as e:
                return render_template("index.html", error=str(e))
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    key = request.args.get("key")
    if key != DEV_KEY:
        return "Unauthorized", 403
    return render_template("dashboard.html", dev_key=DEV_KEY)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
